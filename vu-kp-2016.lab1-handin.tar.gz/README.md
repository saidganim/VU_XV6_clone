# VU_XV6_clone

Clone of XV6 which is being developed by Giulia Frascaria(github.com/giuliafrascaria) and Saidgani Musaev(github.com/saidganim),
during doing Kernep Programming course in Vrije Universiteit Amsterdam.
